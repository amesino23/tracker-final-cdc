import msal
import json
import requests

CLIENT_ID = "f82cb8d2-be44-4ed0-947b-f18158fa5416"
TENANT_ID = "51fcefe4-5ecc-4d3d-9d76-9cfdbf83102a"
AUTHORITY = f"https://login.microsoftonline.com/{TENANT_ID}"
SCOPES = ["https://analysis.windows.net/powerbi/api/.default"]

print("Iniciando proceso de autenticación...")

app = msal.PublicClientApplication(
    client_id=CLIENT_ID,
    authority=AUTHORITY
)

flow = app.initiate_device_flow(scopes=SCOPES)

if "user_code" not in flow:
    raise ValueError("No se pudo crear el flujo de dispositivo.", flow)

print(f"\n{flow['message']}\n")

result = app.acquire_token_by_device_flow(flow)

access_token = None
if "access_token" in result:
    access_token = result['access_token']
    print("¡Autenticación exitosa! Token de acceso obtenido.\n")
else:
    print("Error en la autenticación:")
    if result.get("error"):
        print(result.get("error"))
    if result.get("error_description"):
        print(result.get("error_description"))

if access_token:
    print("Realizando llamada a la API de Power BI para obtener los espacios de trabajo...")
    
    api_url = "https://api.powerbi.com/v1.0/myorg/groups"

    headers = {
        'Authorization': f'Bearer {access_token}'
    }

    response = requests.get(api_url, headers=headers)

    if response.status_code == 200:
        workspaces = response.json()
        print("\n¡Llamada a la API exitosa! Espacios de trabajo encontrados:")
        print(json.dumps(workspaces, indent=2))
    else:
        print(f"\nError al llamar a la API de Power BI: {response.status_code}")
        print(f"Respuesta del servidor: {response.text}")