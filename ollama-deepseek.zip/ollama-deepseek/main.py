import json
from api.api_config import ejecutar_ollama

def cargar_prompts(ruta):
    with open(ruta, 'r', encoding='utf-8') as archivo:
        return json.load(archivo)

def main():
    prompts = cargar_prompts("prompts/prompts.json")

    for categoria, textos in prompts.items():
        print(f"\n=== {categoria.upper()} ===")
        for i, prompt in enumerate(textos, start=1):
            respuesta = ejecutar_ollama(prompt)
            print(f"\nPregunta {i}: {prompt}")
            print("Respuesta:")
            print(respuesta)

if __name__ == "__main__":
    main()
