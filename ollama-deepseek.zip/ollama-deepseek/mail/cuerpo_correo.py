import sqlite3
import base64
import threading
import socket
from datetime import datetime
from pathlib import Path
from flask import Flask, request, redirect, Response
import user_agents
from urllib.parse import urlparse, parse_qs

app = Flask(__name__)
DB_FILE = Path("tracker_profesional.sqlite")
db_lock = threading.Lock()

def inicializar_db():
    with db_lock:
        with sqlite3.connect(DB_FILE) as conn:
            cursor = conn.cursor()
            cursor.execute("""
            CREATE TABLE IF NOT EXISTS Registros (
                ID INTEGER PRIMARY KEY AUTOINCREMENT,
                Destinatario TEXT NOT NULL,
                Campaña TEXT,
                Estado TEXT,
                Direccion_IP TEXT,
                Hostname_IP TEXT,
                Navegador TEXT,
                Sistema_Operativo TEXT,
                Dispositivo TEXT,
                Es_Movil BOOLEAN,
                Idioma TEXT,
                Fecha_Apertura TEXT,
                Fecha_Primer_Clic TEXT,
                URL_Destino TEXT,
                UTM_Source TEXT,
                UTM_Campaign TEXT,
                UTM_Medium TEXT
            );
            """)
            conn.commit()

def obtener_info_peticion(peticion):
    ip = peticion.headers.get('X-Forwarded-For', peticion.remote_addr)
    ua_string = peticion.headers.get('User-Agent', '')
    user_agent = user_agents.parse(ua_string)
    try:
        hostname, _, _ = socket.gethostbyaddr(ip)
    except (socket.herror, socket.gaierror):
        hostname = "No resuelto"
    
    return {
        "ip": ip, "hostname": hostname,
        "nav": f"{user_agent.browser.family} {user_agent.browser.version_string}",
        "so": f"{user_agent.os.family} {user_agent.os.version_string}",
        "disp": user_agent.device.family, "movil": user_agent.is_mobile,
        "lang": peticion.headers.get('Accept-Language', '').split(',')[0]
    }

PIXEL_GIF_DATA = base64.b64decode("R0lGODlhAQABAIAAAP///wAAACH5BAEAAAAALAAAAAABAAEAAAICRAEAOw==")

@app.route("/track/open")
def track_open():
    info = obtener_info_peticion(request)
    destinatario = request.args.get('recipient', 'desconocido')
    campaña = request.args.get('campaign', 'desconocida')
    
    with db_lock:
        with sqlite3.connect(DB_FILE) as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT ID FROM Registros WHERE Destinatario = ? AND Campaña = ?", (destinatario, campaña))
            if not cursor.fetchone():
                sql = """INSERT INTO Registros (Destinatario, Campaña, Estado, Direccion_IP, Hostname_IP, Navegador, Sistema_Operativo, Dispositivo, Es_Movil, Idioma, Fecha_Apertura)
                         VALUES (?, ?, 'Apertura Registrada', ?, ?, ?, ?, ?, ?, ?, ?);"""
                cursor.execute(sql, (destinatario, campaña, info["ip"], info["hostname"], info["nav"], info["so"], info["disp"], info["movil"], info["lang"], datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S")))
                conn.commit()
                print(f"NUEVA APERTURA registrada para {destinatario}")
    return Response(PIXEL_GIF_DATA, mimetype='image/gif')

@app.route("/track/click")
def track_click():
    url_destino = request.args.get('url')
    if not url_destino: return "Error: URL de destino no especificada.", 400
        
    info = obtener_info_peticion(request)
    destinatario = request.args.get('recipient', 'desconocido')
    campaña = request.args.get('campaign', 'desconocida')
    parsed_url = urlparse(url_destino)
    queryParams = parse_qs(parsed_url.query)

    with db_lock:
        with sqlite3.connect(DB_FILE) as conn:
            cursor = conn.cursor()
            sql = """UPDATE Registros SET Estado = 'Clic Realizado', Fecha_Primer_Clic = ?, URL_Destino = ?, UTM_Source = ?, UTM_Campaign = ?, UTM_Medium = ?
                     WHERE Destinatario = ? AND Campaña = ? AND Fecha_Primer_Clic IS NULL;"""
            cursor.execute(sql, (datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S"), url_destino, queryParams.get('utm_source', [None])[0], queryParams.get('utm_campaign', [None])[0], queryParams.get('utm_medium', [None])[0], destinatario, campaña))
            conn.commit()
            print(f"CLIC registrado para {destinatario}")
    return redirect(url_destino)

if __name__ == '__main__':
    inicializar_db()
    app.run(host='0.0.0.0', port=5000, debug=False)