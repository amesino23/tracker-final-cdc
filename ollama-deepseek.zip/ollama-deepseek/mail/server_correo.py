import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from urllib.parse import quote_plus

# --- CONFIGURACIÓN ---
SMTP_SERVER = 'smtp.office365.com'
SMTP_PORT = 587
SMTP_USERNAME = 'do_not_reply@centraldecobranzas.com'
SMTP_PASSWORD = 'yfzvbvqgtvwphwhr'

# !! IMPORTANTE: ESTA URL DEBE SER REEMPLAZADA POR LA DE RENDER.COM !!
TRACKING_SERVER_URL = 'https://TU-APP-DE-RENDER.onrender.com' 

campaign_id = 'Campaña-Profesional-Junio'

lista_destinatarios = [
    'amesino@centraldecobranzas.com',
    'anavarro@centraldecobranzas.com'
]
# --- FIN DE LA CONFIGURACIÓN ---

def enviar_correo_individual(destinatario):
    msg = MIMEMultipart('alternative')
    msg['Subject'] = 'Notificación Final de Sistema de Seguimiento'
    msg['From'] = f"Central de Cobranzas <{SMTP_USERNAME}>"
    msg['To'] = destinatario
    recipient_id = destinatario
    
    # Ejemplo de enlace con parámetros UTM
    url_con_utm = f"https://www.centraldecobranzas.com/?utm_source=email&utm_medium=notificacion&utm_campaign={quote_plus(campaign_id)}"
    pixel_url = f"{TRACKING_SERVER_URL}/track/open?recipient={quote_plus(recipient_id)}&campaign={quote_plus(campaign_id)}"
    click_url = f"{TRACKING_SERVER_URL}/track/click?recipient={quote_plus(recipient_id)}&campaign={quote_plus(campaign_id)}&url={quote_plus(url_con_utm)}"
    
    html_template = f"""
    <!DOCTYPE html><html lang="es"><head><meta charset="UTF-8"><title>Notificación</title></head>
    <body><div style="font-family:Arial,sans-serif;max-width:600px;margin:auto;padding:20px;border:1px solid #eee;">
    <p>Estimado/a Cliente,</p><p>Le informamos que tenemos una actualización importante sobre su cuenta.</p>
    <p><a href="{click_url}" style="background-color:#007bff;color:white;padding:10px 15px;text-decoration:none;border-radius:5px;">Ir al Portal de Clientes</a></p>
    </div><img src="{pixel_url}" width="1" height="1" alt=""></body></html>
    """
    msg.attach(MIMEText(html_template, 'html'))
    return msg

def main():
    if 'TU-APP-DE-RENDER' in TRACKING_SERVER_URL:
        print("ERROR: Edita el archivo y reemplaza 'TRACKING_SERVER_URL' con tu URL real de Render.com")
        return

    print(f"Iniciando envío de la campaña '{campaign_id}'...")
    try:
        with smtplib.SMTP(SMTP_SERVER, SMTP_PORT) as server:
            server.starttls()
            server.login(SMTP_USERNAME, SMTP_PASSWORD)
            for email in lista_destinatarios:
                server.sendmail(SMTP_USERNAME, email, enviar_correo_individual(email).as_string())
                print(f"-> Correo enviado a {email}")
        print("Campaña finalizada.")
    except Exception as e:
        print(f"ERROR CRÍTICO durante el envío: {e}")

if __name__ == '__main__':
    main()